const LICENSE_KEY =
  "mg1wDoDf1SmuZTLnBLdMlU6enrV00o" +
  "vR8LAZs5MrCJhCGo2r4Sskd54nOJ6j" +
  "dwHK33Jc9l9rkBfytLQqm1yYvo+KN/" +
  "Lclmp6ACkLh0uVB5JTx9i3oOGpW1Zj" +
  "sEgZbMnjLeDfRUF2s8QFmY5gQeTNgF" +
  "RqSueN9qwaz4huU6lxmVmjhkS/qbOI" +
  "0d3ihlwdtam0OedHoG6OtlH+nQd6j4" +
  "GRNWiifmqcXvk4obkzSrPEXx5Q7PRr" +
  "SZQsZIiNswkPBXXtgEGgC7/DQWjt6P" +
  "+oDmIku/96Z4gQbGCm+fzXhdGmH7Yd" +
  "wE+OzbUxIJnTUWQpLLKA0vZYalv+Jl" +
  "IcRCejengrCQ==\nU2NhbmJvdFNESw" +
  "psb2NhbGhvc3R8bW1kdGVzdGVyLnZl" +
  "cmNlbC5hcHAKMTY4ODYwMTU5OQo4Mz" +
  "g4NjA3Cjg=\n";

const config = {
  licenseKey: LICENSE_KEY,
  imageResolution: 1024,
  ui: {
    enableCameraSwitchButton: true,
  },
};

ScanbotSDK.initialize(config).then(initPage);

let frameHandler;

function initPage(sdk) {
  sdk.UI.startFrameScanner({
    containerId: "preview-container",
    onFrameDetected: handleFrameDetected,
    onError: console.error,
  }).then((fh) => {
    frameHandler = fh;
  });
}

function handleFrameDetected(result) {
  if (result.barcodeFormat !== ScanbotSDK.BarcodeFormat.UNKNOWN) {
    frameHandler.stop();

    document.getElementById("message-container").innerText = result.text;

    setTimeout(function () {
      document.getElementById("message-container").innerText = "";
      frameHandler.start();
    }, 5000);
  }
}
